Members Contribution For Sprint 4

### Zeiad Badawy - 40247477 - Scrum master/Front-end DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|-----------------------------------------------------------------|
|          Adding payment feature when modifying reservation                 |    4h       |                                                                 |
|          Refactoring code and fixing bugs                 |     5h      |                                                                 |



### Mohamed Saidi - 40248103 - Backend DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|-----------------------------------------------------------------|
| Implemented entirely our unique feature "Recently Viewed Vehicle"                           | 5 days ~ 18h           | For the whole project I was working only at backend, so it took me a lot of time just to understand what was happening in the frontend                                                       | 
|  Documentation                         |     30 min      |                    wiki, issues, member contribution file                                          | 




### Miskat Mahmud - 40250110 - Backend DEVe
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|-----------------------------------------------------------------|
|   Presentation slides                         |   8h    |   Worded on the presentation slides                  |
|   unit testing of backend routes                     |    2h  |                                            |
|   fixes | 1h | backend |




### Matteo Sansone - 40242278 - Front-end DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|-----------------------------------------------------------------|
|             Created the 'My Account' page             |     6h    |              |
|             Meeting Minutes                |  30m   |                                                                 |

### Abdel-Rahman Khalifa - 40253332 - Fullstack DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|-----------------------------------------------------------------|
| Task #349/implement issue schema and backend endpoints| 2h  | backend                                     |
| Task #352/create issues section in admin dashboard|  3h |   frontend                                      |
| Task #356/report an issue section for customers| 4h  | frontend |
| Task #367 add eslint to react and express directories | 1h |  frontend/backend |
|  Acceptance tests for U-14| 30min | documentation |
