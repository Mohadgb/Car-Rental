Members Contribution For Sprint 2

### Zeiad Badawy - 40247477 - Scrum master/Front-end DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|-----------------------------------------------------------------|
|   Make Reservation Form    |      4h     |                                                                 |
|   View Reservations Dashboard for Customers     |     4h      |                                                                 |
|   Modify reservation form for Customers                          |    4h       |                                                                 |
|   Cancel reservation form for Customers                         |     1h      |                                                                 |
|           Acceptance Tests for Start/View/modify/cancel a reservation                |      2h     |                                                                 |


### Mohamed Saidi - 40248103 - Backend DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|-----------------------------------------------------------------|
| Implemented Create Vehicle functionality |    4h       |    Had to solve many problemes related to the database and to the project structure proposed by abderrahmane|
| Implemented Read Vehicle functionality   |   1h        |                                                                 |
| Implemented Update Vehicle functionality |   1h        |                                                                 |
| Implemented Delete Vehicle functionality |   1h        |                                                                 |
| Implemeted the pipeline on Github for Vehicle functionalities   |  5h         |                                                                 |
| Implemented the unit testing for Vehicles functionalities                           |   2h        |                                                                 |
| Documentation                            |      3h     |                                                                 |


### Miskat Mahmud - 40250110 - Backend DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|-----------------------------------------------------------------|
|Created User Story 12                             |   2h        |                                                                 |
|Creted Tasks for us-12                             |     2h      |                                                                 |
|Unit Test for Reservation management                    |      6h     |                                                                 |
|Updating the Reservation Schema                          |   2h        |                                                                 |
|Documentation                          |     2h      |        api endpoints update                                                    |
|Testing and Debugging                             |  5h         |                                                                 |
|External Documentation                           |   1h        | member contribution file, Plan for next sprint file                                                                 |



### Matteo Sansone - 40242278 - Front-end DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|-----------------------------------------------------------------|
| Created browse page design  |    1h     |                                                                 |
| Meeting minutes (2,3,6,7)   |    2h     |                                                                 |
| Created login page          |    3h     |                                                                 |
| Created browse page         |    8h     |                                                                 |



### Abdel-Rahman Khalifa - 40253332 - Fullstack DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|-----------------------------------------------------------------|
|Task#74 read user account functionality | 2h |           backend                                                      |
| Task#66 create user account functionality | 1.5h |          backend                                                       |
| API documentation  | 1.5h | documentation for our API         |  documentation
| Task#76 create user account functionality |  1h  |                     backend                                            |
| Task#75 create user account functionality |  1h  |                     backend                                           |
| Task#94 create browsing page|  2h  | contributed to the task            frontend                         |
| Task#78 implement signup functionality| 1h |             backend                                                    |
| Task#77 implement login functionality| 2h | authentication with Tokens     backend                                  |
| Task#96 create login pop up page | 1h | frontend                                                          |
| Task#95 display vehicles in browse page | 1h | frontend                                                          |
| Task#184 implement admin dashboard | 6h | frontend/backend                                                          |
| Documented User Story 11 | 30min | documentation   |
