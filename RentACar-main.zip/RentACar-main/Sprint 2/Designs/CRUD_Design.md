CRUD Example ([Source](https://budibase.com/blog/crud-app/))

Create: 
![alt text](https://budibase.com/blog/crud-app/images/create.webp)

Read: 
![alt text](https://budibase.com/blog/crud-app/images/read.webp)

Update: 
![alt text](https://budibase.com/blog/crud-app/images/update-2.webp)

Delete: 
![alt text](https://budibase.com/blog/crud-app/images/delete.webp)


