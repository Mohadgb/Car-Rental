const transaction = {
  name: 'John Doe',
  cardNumber: '4242424242424242',
  expDate: '12/22',
  ccv: '123',
  amount: 100,
  date: '2021-01-01T00:00:00.000Z',
  userId: '65ef29928e591664663d138d',
  reservationId: '65e76791e2a679cc50e5765a',
};

module.exports = { transaction };
