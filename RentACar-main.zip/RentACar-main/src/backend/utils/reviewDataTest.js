const review = {
  userID: '611f4ad35217a62c84a8f11a',
  rating: 4,
  comment: 'Great experience overall!',
  branchID: '611f4ad35217a62c84a8f11b',
};

module.exports = { review };
