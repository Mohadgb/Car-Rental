const car = {
  make: 'Jaguar',
  model: 'F-Type',
  price: 80000,
  transmission: 'Automatic',
  numberOfSeats: 2,
  address: '123 Main Street, Cityville',
  colour: 'Red',
  numberOfDoors: 2,
  numberOfBaggage: 2,
  kilometrage: 5000,
  electricalOrFuel: 'Petrol',
  availability: 'In Stock',
  Image: 'https://cdn.motor1.com/images/mgl/ozYE4/s3/bulletproof-mercedes-amg-g63-by-inkas.jpg',
};

module.exports = { car };
