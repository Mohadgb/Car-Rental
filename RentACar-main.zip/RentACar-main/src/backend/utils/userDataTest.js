const user1 = {
  username: 'Alice123',
  first_name: 'Alice',
  last_name: 'Johnson',
  password: 'Alice321!',
  email: 'alice.johnson@example.com',
  phone_number: '+1896543210',
  date_of_birth: '1990-05-15T00:00:00.000Z',
  role: 'customer',
  profile_picture: 'https://media.wired.com/photos/598e35994ab8482c0d6946e0/master/w_1920,h_1280,c_limit/Transpo_G70_TA-518126.jpg',
};
const user2 = {
  username: 'Albert123',
  first_name: 'Albert',
  last_name: 'Johnson',
  password: 'Albert321!',
  email: 'albert.johnson@example.com',
  phone_number: '+1896543210',
  date_of_birth: '1990-05-15T00:00:00.000Z',
  role: 'customer',
  profile_picture: 'https://media.wired.com/photos/598e35994ab8482c0d6946e0/master/w_1920,h_1280,c_limit/Transpo_G70_TA-518126.jpg',
};
const adminUser = {
  username: 'Bob123',
  password: 'StrongPassword123!',
};

module.exports = { adminUser, user1, user2 };
