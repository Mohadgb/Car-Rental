export default function Account(){
    return (<div>Account Page</div>)
}