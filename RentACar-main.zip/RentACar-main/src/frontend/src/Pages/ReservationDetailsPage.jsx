import ModifyReservation from '../components/reservation/ModifyReservation';
export default function ReservationDetailsPage() {
    return (
        <div>
            <ModifyReservation />
        </div>
    );
}