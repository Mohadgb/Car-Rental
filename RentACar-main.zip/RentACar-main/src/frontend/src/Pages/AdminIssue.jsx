import CustomerIssue from "./Issue";

export default function AdminIssue() {
  return <CustomerIssue admin={true} />;
}
