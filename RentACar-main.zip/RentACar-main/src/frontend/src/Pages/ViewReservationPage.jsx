
import ViewReservation from "../components/reservation/ViewReservation.jsx";
export default function ViewReservationPage() {
    return (
        <div>
            <ViewReservation />
        </div>
    );

}