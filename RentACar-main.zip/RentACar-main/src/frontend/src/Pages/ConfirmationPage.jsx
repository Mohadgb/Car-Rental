
import Confirmation from "../components/reservation/Confirmation";

export default function ConfirmationPage() {
    return (
        <div>
            <Confirmation/>
        </div>
    );
}