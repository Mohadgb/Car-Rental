
import MakeReservation from "../components/reservation/MakeReservation.jsx";

export default function MakeReservationPage() {
    return (
        <div>
            <MakeReservation/>
        </div>
    );
}