# Sprint 1
## Contribution for Sprint 1

### Zeiad Badawy - 40247477 - Scrum master/Front-end DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|------------------------------------------------------------------|
| Meeting note taking         | during meetings |                |
| Participate in issue writing during meeting | during meetings |  |
| Wiki for Plan next Sprint - filled out information missing | 40 min |                                             |
| Wiki for git rule - filled out information missing | 30 min |                                             |
| Created a user story of one of the 6 core features | 90 min |                           |
| Created tasks based on user story | 90 min |                           |
| Flowchart in preparation for Sprint 2 | 60 min |                           |
| Design DB Schema | 90 min |                           |


### Mohamed Saidi - 40248103 - Backend DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|------------------------------------------------------------------|
|Creating and filling "Plan next Sprint" Table   | 180 min    |      6th February 2024                                              |
| Creating and filling "Team members Contribution" Table | 120 min | 7th February 2024
| Creating and filling "Task Break down" table       |    120 min       |           8th of January 2024                                          |
| Meeting Minutes files       | 20 min    |      31st January 2024                   |
| Created a user story of one of the 6 core features | 30 min |     2nd of February 2024                     |
| Project Description         | 15 min    |                  29th of January 2024                                      |
| Read me file Template       |    60 min       |           25th of January 2024                                          |







### Miskat Mahmud - 40250110 - Backend DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|------------------------------------------------------------------|
| Created a user story of one of the 6 core features | 90 min |  US-6, Issue number #35                         |
| Updated readme file to include a technology  | 30 min |      Technology Selection                                       |
| Meeting minutes files       | 90 min    |    Created a template, writing meeting minutes                     |
| Team Contribution Google Doc| 60 min   |  team contribution in a google sheet file
| Addition of features in the read me file| 90 min   | User, CRUD or extra features
| Created an additional user story  | 90 min |    US-9, Issue number #105                       |
| Updating plan for next sprint  | 60 min |    Associated tasks and Associated User Story                       |
| Assigning team member for each issue  | 30 min |    Every task related to corresponding User story owner                       |
| Created Issues for Several tasks  | 120 min |    Issue Number: #101, #102, #103, #104, #105, #106, #107, #108                      |
| Verifying every checklist item for Sprint 1 and Submission  | 90 min |    Fixing if anything is not right                       |



### Matteo Sansone - 40242278 - Front-end DEV
| Item                        | Time      | Notes (If needed)                                               |
|-----------------------------|-----------|------------------------------------------------------------------|
| Meeting minutes files        | 60 min    |                         |
| Created a user story of one of the 6 core features | 90 min |                           |
| Created a user story for an additional feature | 60 min |                           |
| Created issues for tasks | 120 min | Issue #: 93, 94, 95, 96, 97, 98|



### Abdel-Rahman Khalifa - 40253332 - Fullstack DEV
| Item                        | Time      | Notes (If needed)                                                 |
|-----------------------------|-----------|-------------------------------------------------------------------|
| Wiki Git Rules Page      | 60 min    | Rules regarding merging, branch naming, pull requests                |
| Created two user stories for two of the 6 core features | 60 min | User stories: #16 & #30                  |
| Created issues for several tasks| 90 min    | Tasks: #66, #74, #75, #76, #77, #78, #79, #80, #81, #82, #85  |             |
| Developed the YAML workflow file for the pipeline| 75 min | Now a build is executed with each PR            |
| Implemented Task #85 | 30 min | Created an initial structure for the project to test the pipeline           |
| Updated the structure of some meeting minutes files | 45 min | To match the meeting minutes template        |
| Readme file (Installation section and some updates in the Contribution section) | 45 min |                  |
| 



